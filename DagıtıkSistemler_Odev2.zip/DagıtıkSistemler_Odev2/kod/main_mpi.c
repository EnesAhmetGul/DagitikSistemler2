#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <ctype.h>

#include "worker_openmp.h"
#include "image_helper.h"

#define GORSEL_KLASORU "/data"              // Görsellerin bulunduğu dizin
#define MAKS_ISIM_UZUNLUGU 256              // Maksimum dosya ismi uzunluğu

// Dosya adının .jpg ya da .jpeg olup olmadığını kontrol eder (büyük/küçük harf duyarsız)
int jpg_mi(const char* ad) {
    const char* uzanti = strrchr(ad, '.');
    return uzanti && (strcasecmp(uzanti, ".jpg") == 0 || strcasecmp(uzanti, ".jpeg") == 0);
}

int main(int argc, char** argv) {
    int sira, toplam_surec;

    // MPI başlatılır
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &sira);           // Bu düğümün sırası
    MPI_Comm_size(MPI_COMM_WORLD, &toplam_surec);   // Toplam düğüm sayısı

    // Tüm dosya adlarını saklayacağımız dizi
    char tum_dosyalar[30000][MAKS_ISIM_UZUNLUGU];
    int toplam_dosya = 0;

    // Sadece sıfırıncı node dizindeki dosyaları okur
    if (sira == 0) {
        DIR* klasor = opendir(GORSEL_KLASORU);
        if (klasor == NULL) {
            fprintf(stderr, "Klasör açılamadı: %s\n", GORSEL_KLASORU);
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        struct dirent* girdi;
        while ((girdi = readdir(klasor)) != NULL) {
            if (jpg_mi(girdi->d_name)) {
                strncpy(tum_dosyalar[toplam_dosya], girdi->d_name, MAKS_ISIM_UZUNLUGU);
                toplam_dosya++;
            }
        }

        closedir(klasor);
    }

    // Diğer node'lara dosya isimlerini ve toplam sayıyı gönder
    MPI_Bcast(&toplam_dosya, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(tum_dosyalar, toplam_dosya * MAKS_ISIM_UZUNLUGU, MPI_CHAR, 0, MPI_COMM_WORLD);

    RGB ortalama = {0, 0, 0}; // Ortalama RGB tutulur
    int sayac = 0;            // Kaç dosya işlendi?

    // Her node kendisine ait index’lerdeki dosyaları işler (örneğin node 1: 1, 4, 7, ...)
    for (int i = sira; i < toplam_dosya; i += toplam_surec) {
        char tam_yol[512];
        snprintf(tam_yol, sizeof(tam_yol), "%s/%s", GORSEL_KLASORU, tum_dosyalar[i]);

        // Görselin ortalama RGB’sini hesapla
        RGB guncel_rgb = ortalama_rgb_hesapla(tam_yol);

        // Eğer -1 değer dönerse görsel açılamamış demektir
        if (guncel_rgb.r == -1 && guncel_rgb.g == -1 && guncel_rgb.b == -1) {
            FILE* hata_dosya = fopen("/output/hatalar.txt", "a");
            fprintf(hata_dosya, "Hatalı resim: %s\n", tam_yol);
            fclose(hata_dosya);
            continue;
        }

        // Güncel ortalamayı hesapla (önceki değerler ile birlikte)
        sayac++;
        ortalama.r = ((ortalama.r * (sayac - 1)) + guncel_rgb.r) / sayac;
        ortalama.g = ((ortalama.g * (sayac - 1)) + guncel_rgb.g) / sayac;
        ortalama.b = ((ortalama.b * (sayac - 1)) + guncel_rgb.b) / sayac;

        // Sonucu ortak dosyaya yaz
        FILE* dosya = fopen("/output/results.txt", "a");
        fprintf(dosya, "Döngü %d Ortalama RGB = (%.2f, %.2f, %.2f), İşlenen Görsel: %s\n",
                sayac, ortalama.r, ortalama.g, ortalama.b, tum_dosyalar[i]);
        fclose(dosya);
    }

    // MPI ortamını kapat
    MPI_Finalize();
    return 0;
}
