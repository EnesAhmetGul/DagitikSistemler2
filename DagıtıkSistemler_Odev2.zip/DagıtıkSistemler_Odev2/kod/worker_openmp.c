#include "worker_openmp.h"
#include "image_helper.h"
#include <stdio.h>

/*
 * OpenMP kullanarak bir grup görselin ortalama RGB değerini hesaplar.
 * Her işlemci çekirdeği bir görseli paralel olarak işler.
 * Sonuçlar "output/results.txt" dosyasına yazılır.
 */
void goruntuleri_isle_openmp(char dosya_adlari[][256], int adet, int siralama) {
    double r_toplam = 0, g_toplam = 0, b_toplam = 0;
    int gecerli_sayisi = 0;

    // OpenMP paralel döngüsü, RGB toplama işlemleri reduction ile yapılır
    #pragma omp parallel for reduction(+:r_toplam, g_toplam, b_toplam, gecerli_sayisi)
    for (int i = 0; i < adet; i++) {
        char tam_yol[512];
        snprintf(tam_yol, sizeof(tam_yol), "/data/%s", dosya_adlari[i]);

        RGB rgb = ortalama_rgb_hesapla(tam_yol);

        if (rgb.r + rgb.g + rgb.b > 0) {
            r_toplam += rgb.r;
            g_toplam += rgb.g;
            b_toplam += rgb.b;
            gecerli_sayisi++;
        }
    }

    // Sonuçları çıktı dosyasına yaz
    FILE* dosya = fopen("/output/results.txt", "a");
    fprintf(dosya, "Düğüm %d: Ortalama RGB = (%.2f, %.2f, %.2f), Toplam Görsel: %d\n",
            siralama, r_toplam / gecerli_sayisi, g_toplam / gecerli_sayisi, b_toplam / gecerli_sayisi, gecerli_sayisi);
    fclose(dosya);
}
