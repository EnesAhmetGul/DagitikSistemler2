#ifndef GOREVLI_OPENMP_H
#define GOREVLI_OPENMP_H

/*
 * OpenMP ile paralel görsel işleme fonksiyonu.
 * dosya_adlari: işlenecek dosya isimleri (256 karaktere kadar)
 * adet: kaç adet dosya olduğu
 * siralama: MPI düğüm sırası (rank)
 */
void goruntuleri_isle_openmp(char dosya_adlari[][256], int adet, int siralama);

#endif
