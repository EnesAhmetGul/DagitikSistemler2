#ifndef GORSEL_YARDIMCISI_H
#define GORSEL_YARDIMCISI_H

// Ortalama RGB değerlerini temsil eden yapı
typedef struct {
    double r, g, b;  // Kırmızı, Yeşil, Mavi
} RGB;

// JPEG dosyasının ortalama RGB değerlerini hesaplayan fonksiyon
RGB ortalama_rgb_hesapla(const char* dosya_adi);

#endif
