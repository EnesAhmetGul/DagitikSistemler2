#include "image_helper.h"
#include <stdio.h>
#include <jpeglib.h>

/*
 * Ortalama RGB değerlerini hesaplayan fonksiyon.
 * Girdi olarak resim dosyasının adını alır (JPEG formatında olmalı),
 * çıktısı bir RGB yapısıdır (double r, g, b).
 */
RGB ortalama_rgb_hesapla(const char* dosya_adi) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE* girdi_dosyasi;
    JSAMPARRAY tampon;
    int satir_uzunlugu;

    RGB sonuc = {0, 0, 0};

    // Dosya açılamazsa hata ver ve sıfır döndür
    if ((girdi_dosyasi = fopen(dosya_adi, "rb")) == NULL) {
        fprintf(stderr, "Dosya açılamadı: %s\n", dosya_adi);
        return sonuc;
    }

    // JPEG işleyici ayarları
    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);
    jpeg_stdio_src(&cinfo, girdi_dosyasi);
    jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);

    satir_uzunlugu = cinfo.output_width * cinfo.output_components;
    tampon = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, satir_uzunlugu, 1);

    // Piksel değerlerini biriktir
    unsigned long r = 0, g = 0, b = 0;
    int piksel_sayisi = 0;

    while (cinfo.output_scanline < cinfo.output_height) {
        jpeg_read_scanlines(&cinfo, tampon, 1);
        for (unsigned int i = 0; i < satir_uzunlugu; i += 3) {
            r += tampon[0][i];       // Kırmızı bileşen
            g += tampon[0][i + 1];   // Yeşil bileşen
            b += tampon[0][i + 2];   // Mavi bileşen
            piksel_sayisi++;
        }
    }

    // JPEG işlemlerini bitir
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(girdi_dosyasi);

    // Ortalama RGB değeri hesapla
    sonuc.r = (double)r / piksel_sayisi;
    sonuc.g = (double)g / piksel_sayisi;
    sonuc.b = (double)b / piksel_sayisi;

    return sonuc;
}
